﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarInventory
{
    public partial class frmCarInventory : Form
    {
        public frmCarInventory()
        {
            InitializeComponent();
  
        }
        void ResetData()
        {
            cmbMake.Text = "--Select--";
            tbModel.Text = "";
            cmbYear.Text = "--Select--";
            tbPrice.Text = "";
            chkNew.Checked = false;
            lblResult.Text = "";
        }
        int labCount = 0;

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnReset_Click(object sender, EventArgs e)
        {

            ResetData();

        }

        private void btnEnter_Click(object sender, EventArgs e)
        {

            
            labCount = 1;
           
            CarClass carObject = new CarClass();
            carObject.Year = 0;
            carObject.Price = 0;

            carObject.Idnumber = labCount;
            carObject.Make = cmbMake.Text;
            carObject.Model = tbModel.Text;
            carObject.Year = Convert.ToInt32(cmbYear.Text);
            carObject.Price = Convert.ToDecimal(tbPrice.Text);

            
            ListViewItem item = new ListViewItem();
            if(chkNew.Checked == true)
            {
                item.Checked = true;
                labCount++;
            }
            else
            {
                item.Checked = false;
                labCount++;
            }

            if(carObject.Make == "" || carObject.Make == "--Select--" || carObject.Model == "" || carObject.Price == 0 || carObject.Year == 0)
            {
                lblResult.Text = "Please Fill all the Informations, any field can be empty.";
            }
            else
            {

            
            item.SubItems.Add(Convert.ToString(carObject.Idnumber));
            item.SubItems.Add(carObject.Make);
            item.SubItems.Add(carObject.Model);
            item.SubItems.Add(Convert.ToString(carObject.Year));
            item.SubItems.Add(Convert.ToString(carObject.Price));
            lvwCarList.Items.Add(item);

            ResetData();

            lblResult.Text = "It works!";
        }
        }

        private void tbModel_KeyPress(object sender, KeyPressEventArgs e)
        {
            if(!char.IsControl(e.KeyChar) && !char.IsLetter(e.KeyChar) && !char.IsWhiteSpace(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void tbPrice_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }
    }
}
