﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
/*
 * Name: Deivid Santo
 * ID: 100731640
 * Date: 2020-07-16
 * Description : Lab 4 - .Net
 * 
 * */
namespace CarInventory
{
    public partial class frmCarInventory : Form
    {
        public frmCarInventory()
        {
            InitializeComponent();
  
        }
        void ResetData() //Function to reset the inserted data 
        {
            cmbMake.Text = ""; //set the Make to empty
            tbModel.Text = ""; //Set the model to empty 
            cmbYear.Text = ""; //Set the Year to empty 
            tbPrice.Text = ""; //Set the price to empty
            chkNew.Checked = false; //Uncheck the New checkbox 
            lblResult.Text = ""; // Clear the output messages 
        }
        
        /// <summary>
        /// Closes the program when Exit button clicked
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close(); // close the program 
        }
        /// <summary>
        /// Reset all the fields when Reset button is clicked
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnReset_Click(object sender, EventArgs e)
        {

            ResetData(); //calls the function and resets all data

        }
        /// <summary>
        /// Add data to the listview when Enter Button is clicked 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnEnter_Click(object sender, EventArgs e)
        {

            
             int labCount = 1; // declares the counter as int variable and sets it value to 1
           
            CarClass carObject = new CarClass(); //instancialize the CarClass 
            carObject.Year = 0; //sets the year to 0
            carObject.Price = 0; //sets the price to 0

            carObject.Idnumber = labCount; //sets idNumber to the value of labCount.
            carObject.Make = cmbMake.Text; //attributes the value from the Make to the the class object
            carObject.Model = tbModel.Text; // attributes the model inputed by the user to the class object 
            carObject.Year = Convert.ToInt32(cmbYear.Text); // converts the value from string to int and attributes to its class object
            carObject.Price = Convert.ToDecimal(tbPrice.Text); //convert the value from string to decimal and attributes to its class object

            
            ListViewItem item = new ListViewItem(); //sets the instancialization of the item for listview
            if(chkNew.Checked == true) //condition to check if the New status if checked or not
            {
                item.Checked = true; //sets the item to true (checked)
                labCount++; //counter +1
            }
            else
            {
                item.Checked = false; //sets the item to false(not checked) 
                labCount++; //counter +1
            }

            if(carObject.Make == "" || carObject.Make == "--Select--" || carObject.Model == "" || carObject.Price == 0 || carObject.Year == 0) //if any value is empty outputs a message 
            {
                lblResult.Text = "Please Fill all the Informations, any field can be empty."; //outputs a message for the user
            }
            else
            {

            
            item.SubItems.Add(Convert.ToString(carObject.Idnumber)); //add IDnumber to the listview
            item.SubItems.Add(carObject.Make); // add make to the listview
            item.SubItems.Add(carObject.Model); // add model to the listview
            item.SubItems.Add(Convert.ToString(carObject.Year)); //add year to the listview (convert to string)
            item.SubItems.Add(Convert.ToString(carObject.Price)); //add price to the listview (conver to string)
            lvwCarList.Items.Add(item); //add the item to listview

            ResetData(); //clear the data for next input

            lblResult.Text = "It works!"; //outputs a message on the message box
        }
        }
        /// <summary>
        /// validade the Model field 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tbModel_KeyPress(object sender, KeyPressEventArgs e)
        {
            if(!char.IsControl(e.KeyChar) && !char.IsLetter(e.KeyChar) && !char.IsWhiteSpace(e.KeyChar))
            {
                e.Handled = true;
            }
        }
        /// <summary>
        /// validade the price field
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tbPrice_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }
    }
}
