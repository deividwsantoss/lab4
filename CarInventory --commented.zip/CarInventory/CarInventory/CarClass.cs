﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarInventory
{
    public class CarClass //create class for the CAR
    {
        //private variables for the car
        private int identificationNumber;
        private string carMake;
        private string carModel;
        private int carYear;
        private decimal carPrice;
        private bool NewStatus;

        //create gets and sets for each variable
        public int Idnumber
        {
            get { return identificationNumber; }
            set { identificationNumber = value; }
        }

        public string Make
        {
            get { return carMake; }
            set { carMake = value; }
        }

        public  string Model
        {
            get { return carModel; }
            set { carModel = value; }
        }

        public int Year
        {
            get { return carYear; }
            set { carYear = value; }
        }
        public decimal Price
        {
            get;set;
        }
        
        


    }
}
