﻿namespace CarInventory
{
    partial class frmCarInventory
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmCarInventory));
            this.lblMake = new System.Windows.Forms.Label();
            this.lblModel = new System.Windows.Forms.Label();
            this.lblYear = new System.Windows.Forms.Label();
            this.lblPrice = new System.Windows.Forms.Label();
            this.lblNew = new System.Windows.Forms.Label();
            this.cmbMake = new System.Windows.Forms.ComboBox();
            this.tbModel = new System.Windows.Forms.TextBox();
            this.cmbYear = new System.Windows.Forms.ComboBox();
            this.tbPrice = new System.Windows.Forms.TextBox();
            this.chkNew = new System.Windows.Forms.CheckBox();
            this.lblResult = new System.Windows.Forms.Label();
            this.btnEnter = new System.Windows.Forms.Button();
            this.btnReset = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.ttCarInventory = new System.Windows.Forms.ToolTip(this.components);
            this.lvwCarList = new System.Windows.Forms.ListView();
            this.New = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.ID = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Make = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Model = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Year = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Price = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.SuspendLayout();
            // 
            // lblMake
            // 
            this.lblMake.Location = new System.Drawing.Point(12, 41);
            this.lblMake.Name = "lblMake";
            this.lblMake.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lblMake.Size = new System.Drawing.Size(42, 20);
            this.lblMake.TabIndex = 0;
            this.lblMake.Text = "Make ";
            // 
            // lblModel
            // 
            this.lblModel.Location = new System.Drawing.Point(12, 68);
            this.lblModel.Name = "lblModel";
            this.lblModel.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lblModel.Size = new System.Drawing.Size(42, 20);
            this.lblModel.TabIndex = 1;
            this.lblModel.Text = "Model";
            // 
            // lblYear
            // 
            this.lblYear.Location = new System.Drawing.Point(12, 94);
            this.lblYear.Name = "lblYear";
            this.lblYear.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lblYear.Size = new System.Drawing.Size(42, 20);
            this.lblYear.TabIndex = 2;
            this.lblYear.Text = "Year";
            // 
            // lblPrice
            // 
            this.lblPrice.Location = new System.Drawing.Point(12, 115);
            this.lblPrice.Name = "lblPrice";
            this.lblPrice.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lblPrice.Size = new System.Drawing.Size(42, 20);
            this.lblPrice.TabIndex = 3;
            this.lblPrice.Text = "Price";
            // 
            // lblNew
            // 
            this.lblNew.Location = new System.Drawing.Point(12, 141);
            this.lblNew.Name = "lblNew";
            this.lblNew.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lblNew.Size = new System.Drawing.Size(42, 20);
            this.lblNew.TabIndex = 4;
            this.lblNew.Text = "New";
            // 
            // cmbMake
            // 
            this.cmbMake.FormattingEnabled = true;
            this.cmbMake.Items.AddRange(new object[] {
            "Honda",
            "Volkswagen",
            "Hyundai",
            "Ford",
            "Chevrolet",
            "Fiat"});
            this.cmbMake.Location = new System.Drawing.Point(75, 38);
            this.cmbMake.Name = "cmbMake";
            this.cmbMake.Size = new System.Drawing.Size(121, 21);
            this.cmbMake.TabIndex = 0;
            this.cmbMake.Text = "--Select--";
            this.ttCarInventory.SetToolTip(this.cmbMake, "Select Car make");
            // 
            // tbModel
            // 
            this.tbModel.Location = new System.Drawing.Point(75, 65);
            this.tbModel.Name = "tbModel";
            this.tbModel.Size = new System.Drawing.Size(121, 20);
            this.tbModel.TabIndex = 1;
            this.ttCarInventory.SetToolTip(this.tbModel, "Input car Model");
            this.tbModel.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbModel_KeyPress);
            // 
            // cmbYear
            // 
            this.cmbYear.FormattingEnabled = true;
            this.cmbYear.Items.AddRange(new object[] {
            "2010",
            "2011",
            "2012",
            "2013",
            "2014",
            "2015",
            "2016",
            "2017",
            "2018",
            "2019",
            "2020"});
            this.cmbYear.Location = new System.Drawing.Point(75, 91);
            this.cmbYear.Name = "cmbYear";
            this.cmbYear.Size = new System.Drawing.Size(121, 21);
            this.cmbYear.TabIndex = 2;
            this.ttCarInventory.SetToolTip(this.cmbYear, "Select Car Year");
            // 
            // tbPrice
            // 
            this.tbPrice.Location = new System.Drawing.Point(75, 118);
            this.tbPrice.Name = "tbPrice";
            this.tbPrice.Size = new System.Drawing.Size(121, 20);
            this.tbPrice.TabIndex = 3;
            this.ttCarInventory.SetToolTip(this.tbPrice, "Input car Price");
            this.tbPrice.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbPrice_KeyPress);
            // 
            // chkNew
            // 
            this.chkNew.AutoSize = true;
            this.chkNew.Location = new System.Drawing.Point(75, 144);
            this.chkNew.Name = "chkNew";
            this.chkNew.Size = new System.Drawing.Size(15, 14);
            this.chkNew.TabIndex = 4;
            this.chkNew.UseVisualStyleBackColor = true;
            // 
            // lblResult
            // 
            this.lblResult.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblResult.Location = new System.Drawing.Point(9, 336);
            this.lblResult.Name = "lblResult";
            this.lblResult.Size = new System.Drawing.Size(381, 95);
            this.lblResult.TabIndex = 11;
            this.ttCarInventory.SetToolTip(this.lblResult, "Results of car inverntory input");
            // 
            // btnEnter
            // 
            this.btnEnter.Location = new System.Drawing.Point(152, 448);
            this.btnEnter.Name = "btnEnter";
            this.btnEnter.Size = new System.Drawing.Size(75, 23);
            this.btnEnter.TabIndex = 5;
            this.btnEnter.Text = "Enter";
            this.ttCarInventory.SetToolTip(this.btnEnter, "Add to the inventory list");
            this.btnEnter.UseVisualStyleBackColor = true;
            this.btnEnter.Click += new System.EventHandler(this.btnEnter_Click);
            // 
            // btnReset
            // 
            this.btnReset.Location = new System.Drawing.Point(233, 448);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(75, 23);
            this.btnReset.TabIndex = 6;
            this.btnReset.Text = "Reset";
            this.ttCarInventory.SetToolTip(this.btnReset, "Reset data");
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // btnExit
            // 
            this.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnExit.Location = new System.Drawing.Point(314, 448);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(75, 23);
            this.btnExit.TabIndex = 7;
            this.btnExit.Text = "Exit";
            this.ttCarInventory.SetToolTip(this.btnExit, "Exit program");
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // lvwCarList
            // 
            this.lvwCarList.BackColor = System.Drawing.SystemColors.Window;
            this.lvwCarList.CheckBoxes = true;
            this.lvwCarList.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.New,
            this.ID,
            this.Make,
            this.Model,
            this.Year,
            this.Price});
            this.lvwCarList.ForeColor = System.Drawing.SystemColors.InfoText;
            this.lvwCarList.HideSelection = false;
            this.lvwCarList.Location = new System.Drawing.Point(9, 164);
            this.lvwCarList.Name = "lvwCarList";
            this.lvwCarList.Size = new System.Drawing.Size(381, 169);
            this.lvwCarList.TabIndex = 15;
            this.ttCarInventory.SetToolTip(this.lvwCarList, "List of car inventory");
            this.lvwCarList.UseCompatibleStateImageBehavior = false;
            this.lvwCarList.View = System.Windows.Forms.View.Details;
            // 
            // New
            // 
            this.New.Text = "New";
            // 
            // ID
            // 
            this.ID.Text = "ID";
            this.ID.Width = 25;
            // 
            // Make
            // 
            this.Make.Text = "Make";
            this.Make.Width = 80;
            // 
            // Model
            // 
            this.Model.Text = "Model";
            this.Model.Width = 80;
            // 
            // Year
            // 
            this.Year.Text = "Year";
            this.Year.Width = 80;
            // 
            // Price
            // 
            this.Price.Text = "Price";
            this.Price.Width = 80;
            // 
            // frmCarInventory
            // 
            this.AcceptButton = this.btnEnter;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btnExit;
            this.ClientSize = new System.Drawing.Size(402, 483);
            this.Controls.Add(this.lvwCarList);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.btnEnter);
            this.Controls.Add(this.lblResult);
            this.Controls.Add(this.chkNew);
            this.Controls.Add(this.tbPrice);
            this.Controls.Add(this.cmbYear);
            this.Controls.Add(this.tbModel);
            this.Controls.Add(this.cmbMake);
            this.Controls.Add(this.lblNew);
            this.Controls.Add(this.lblPrice);
            this.Controls.Add(this.lblYear);
            this.Controls.Add(this.lblModel);
            this.Controls.Add(this.lblMake);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmCarInventory";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Car Inventory";
            this.ttCarInventory.SetToolTip(this, "Car inventory ");
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblMake;
        private System.Windows.Forms.Label lblModel;
        private System.Windows.Forms.Label lblYear;
        private System.Windows.Forms.Label lblPrice;
        private System.Windows.Forms.Label lblNew;
        private System.Windows.Forms.ComboBox cmbMake;
        private System.Windows.Forms.TextBox tbModel;
        private System.Windows.Forms.ComboBox cmbYear;
        private System.Windows.Forms.TextBox tbPrice;
        private System.Windows.Forms.CheckBox chkNew;
        private System.Windows.Forms.Label lblResult;
        private System.Windows.Forms.Button btnEnter;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.ToolTip ttCarInventory;
        private System.Windows.Forms.ListView lvwCarList;
        private System.Windows.Forms.ColumnHeader New;
        private System.Windows.Forms.ColumnHeader Make;
        private System.Windows.Forms.ColumnHeader Model;
        private System.Windows.Forms.ColumnHeader Year;
        private System.Windows.Forms.ColumnHeader Price;
        private System.Windows.Forms.ColumnHeader ID;
    }
}

